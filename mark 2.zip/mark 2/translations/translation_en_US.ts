<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>you are not going to leave me alone, are you?</source>
            <comment>Text</comment>
            <translation type="unfinished">you are not going to leave me alone, are you?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (1)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>I heard vibrance starts today. I hope you've booked your pro show tickets.</source>
            <comment>Text</comment>
            <translation type="unfinished">I heard vibrance starts today. I hope you've booked your pro show tickets.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (2)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>that's good to hear. i hope you have a great evening.</source>
            <comment>Text</comment>
            <translation type="unfinished">that's good to hear. i hope you have a great evening.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (3)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>I'm sorry. I didn't catch that. </source>
            <comment>Text</comment>
            <translation type="unfinished">I'm sorry. I didn't catch that. </translation>
        </message>
    </context>
</TS>
