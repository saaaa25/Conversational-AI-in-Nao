<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
    <context>
        <name>behavior_1/behavior.xar:/BTS</name>
        <message>
            <source>Yes I do! I like their music.</source>
            <comment>Text</comment>
            <translation type="obsolete">Yes I do! I like their music.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/BTS (1)</name>
        <message>
            <source>Yes I do! I like their music.</source>
            <comment>Text</comment>
            <translation type="obsolete">Yes I do! I like their music.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Get Localized Text</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Hi there</name>
        <message>
            <source>Hi there.</source>
            <comment>Text</comment>
            <translation type="obsolete">Hi there.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Not Recognized</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Sorry, I did not catch that. Could you repeat again?</source>
            <comment>Text</comment>
            <translation type="unfinished">Sorry, I did not catch that. Could you repeat again?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Not Recognized (1)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Sorry, I did not catch that. Could you repeat again?</source>
            <comment>Text</comment>
            <translation type="unfinished">Sorry, I did not catch that. Could you repeat again?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Recognized</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="obsolete">Hello</translation>
        </message>
        <message>
            <source>Why are you apologizing?</source>
            <comment>Text</comment>
            <translation type="obsolete">Why are you apologizing?</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>&quot;You're not going to leave me alone, are you?&quot;</source>
            <comment>Text</comment>
            <translation type="unfinished">&quot;You're not going to leave me alone, are you?&quot;</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Recognized (1)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>&quot;You're not going to leave me alone, are you?&quot;</source>
            <comment>Text</comment>
            <translation type="unfinished">&quot;You're not going to leave me alone, are you?&quot;</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Hello</source>
            <comment>Text</comment>
            <translation>Hello</translation>
        </message>
        <message>
            <source>Yes I do! I like their music.</source>
            <comment>Text</comment>
            <translation type="obsolete">Yes I do! I like their music.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (1)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Sorry, I did not catch that. Could you repeat again?</source>
            <comment>Text</comment>
            <translation type="obsolete">Sorry, I did not catch that. Could you repeat again?</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>I heard Tea-Time restaurent above Gymkhana is a popular food spot right now.</source>
            <comment>Text</comment>
            <translation type="unfinished">I heard Tea-Time restaurent above Gymkhana is a popular food spot right now.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (2)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="obsolete">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>I am learning. Please don't ask me to dance.</source>
            <comment>Text</comment>
            <translation type="unfinished">I am learning. Please don't ask me to dance.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (3)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <source>Vibrance starts on this Thursday. I hope you have booked your Pro-show tickets.</source>
            <comment>Text</comment>
            <translation type="obsolete">Vibrance starts on this Thursday. I hope you have booked your Pro-show tickets.</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>Vibrance starts on this Thursday. I hope you have collected your Pro-show tickets.</source>
            <comment>Text</comment>
            <translation type="unfinished">Vibrance starts on this Thursday. I hope you have collected your Pro-show tickets.</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (4)</name>
        <message>
            <source>Hello</source>
            <comment>Text</comment>
            <translation type="vanished">Hello</translation>
        </message>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>I heard Vibrance is taking place today. Have you booked the pro-show tickets?</source>
            <comment>Text</comment>
            <translation type="unfinished">I heard Vibrance is taking place today. Have you booked the pro-show tickets?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Say (5)</name>
        <message>
            <location filename="behavior_1/behavior.xar" line="0"/>
            <source>That's good to hear. I hope you enjoy</source>
            <comment>Text</comment>
            <translation type="unfinished">That's good to hear. I hope you enjoy</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Sorry I didnt catch that</name>
        <message>
            <source>Sorry, I did not catch that. Could you repeat again?</source>
            <comment>Text</comment>
            <translation type="obsolete">Sorry, I did not catch that. Could you repeat again?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Sorry I didnt catch that (1)</name>
        <message>
            <source>Sorry, I did not catch that. Could you repeat again?</source>
            <comment>Text</comment>
            <translation type="obsolete">Sorry, I did not catch that. Could you repeat again?</translation>
        </message>
    </context>
    <context>
        <name>behavior_1/behavior.xar:/Sorry I didnt catch that.</name>
        <message>
            <source>Sorry, I did not catch that. Could you repeat again?</source>
            <comment>Text</comment>
            <translation type="obsolete">Sorry, I did not catch that. Could you repeat again?</translation>
        </message>
    </context>
</TS>
